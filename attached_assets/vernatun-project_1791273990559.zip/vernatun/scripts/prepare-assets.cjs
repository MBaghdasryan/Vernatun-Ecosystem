const sharp = require('C:/Users/McCloud/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
(async()=>{
 await sharp('public/assets/architecture.png').resize(1536).webp({quality:85}).toFile('public/assets/architecture.webp');
 await sharp('public/assets/vernatun-original.png').extract({left:332,top:208,width:361,height:339}).resize(64,64,{fit:'contain',background:'#fcfbf9'}).png().toFile('public/assets/favicon.png');
 console.log('Prepared architecture WebP and favicon from original brand asset.');
})();
