"""Create a source archive without secrets, local data, dependencies or captures."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import os
root = Path(__file__).resolve().parent.parent
target = root / 'vernatun-project.zip'
excluded = {'node_modules','dist','dist-server','.git','.agents','.codex','.local','.sites-runtime','__pycache__','coverage'}
with ZipFile(target, 'w', ZIP_DEFLATED, compresslevel=9) as archive:
    for directory, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in excluded]
        for name in files:
            path = Path(directory) / name
            if path.suffix in {'.zip','.tsbuildinfo','.log'}: continue
            if name.startswith('.env') and name != '.env.example': continue
            if path.parent == root and path.suffix == '.png': continue
            if path.is_symlink(): continue
            archive.write(path, Path('vernatun') / path.relative_to(root))
with ZipFile(target) as archive:
    assert archive.testzip() is None
    assert not any('/.local/' in name or name.endswith('/.env') for name in archive.namelist())
    print(f'Archive verified: {len(archive.namelist())} files, {target.stat().st_size / 1024 / 1024:.2f} MB')
