import {randomBytes} from 'node:crypto';
import {access,writeFile} from 'node:fs/promises';
try{await access('.env');console.log('.env already exists; preserved.')}catch{
 const password=randomBytes(24).toString('base64url');
 const secret=randomBytes(48).toString('hex');
 await writeFile('.env',`NODE_ENV=development\nPORT=3001\nAPP_ORIGIN=http://localhost:5173\nPOSTGRES_USER=vernatun\nPOSTGRES_PASSWORD=${password}\nPOSTGRES_DB=vernatun\nDATABASE_URL=postgresql://vernatun:${password}@localhost:5434/vernatun\nSESSION_SECRET=${secret}\nDEMO_SEED_ENABLED=true\n`,{mode:0o600,flag:'wx'});
 console.log('Created local .env with random secrets. No secrets printed.');
}
