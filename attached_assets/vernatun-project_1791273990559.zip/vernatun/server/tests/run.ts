import 'dotenv/config';
import pg from 'pg';
import {spawnSync} from 'node:child_process';
const source=process.env.DATABASE_URL;if(!source)throw new Error('DATABASE_URL is required');
const url=new URL(source);url.pathname='/vernatun_test';
const admin=new pg.Client({connectionString:source});await admin.connect();if(!(await admin.query("SELECT 1 FROM pg_database WHERE datname='vernatun_test'")).rowCount)await admin.query('CREATE DATABASE vernatun_test');await admin.end();
const env={...process.env,NODE_ENV:'test',DATABASE_URL:url.toString(),DEMO_SEED_ENABLED:'true'};
for(const args of [['server/migrate.ts'],['server/seed.ts'],['server/seed-modules.ts'],['--test','server/tests/security.test.ts'],['--test','server/tests/workflow.test.ts'],['--test','server/tests/business.test.ts'],['--test','server/tests/services.test.ts'],['--test','server/tests/lifecycle.test.ts']]){const child=spawnSync(process.execPath,['node_modules/tsx/dist/cli.mjs',...args],{env,stdio:'inherit'});if(child.status!==0)process.exit(child.status??1)}
