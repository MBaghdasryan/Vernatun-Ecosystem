# Роли и маршруты

Актуальные назначения, область и сроки проверяются сервером. Наличие роли не обходит выключенный модуль.

| Роль | Маршрут | Каталог разрешений |
|---|---|---|
| platform_admin | /console/overview | organizations.read, organizations.manage, platform.audit, platform.invite, subscriptions.manage, onboarding.manage |
| support | /console/onboarding | support.queue, support.access.request, support.cases, onboarding.manage |
| org_admin | /os/organization | properties.read, properties.manage, people.read, people.invite, roles.assign, modules.read, modules.manage, audit.read, support.access.approve, imports.manage, support.cases.create, documents.read, documents.manage, organization.settings |
| portfolio_owner | /os/portfolio | properties.read, billing.read, reports.read, expenses.read, expenses.approve, reports.export, leases.read |
| developer | /os/development | properties.read, defects.read, defects.manage, defects.accept, handover.read, handover.manage |
| manager | /hayat/management | properties.read, people.read, requests.read, requests.assign, workorders.accept, announcements.read, billing.read, announcements.manage, assets.read, assets.manage, meters.manage, meetings.read, meetings.manage, expenses.read, expenses.manage, reports.export, documents.read, documents.manage, leases.read, leases.manage |
| accountant | /os/accounting | properties.read, billing.read, billing.calculate, billing.publish, payments.reconcile, expenses.read, expenses.manage, reports.export |
| dispatcher | /hayat/dispatch | properties.read, requests.read, requests.assign |
| technician | /hayat/my-work | workorders.assigned, workorders.execute |
| contractor | /hayat/contractor | defects.assigned, defects.execute |
| security | /hayat/security | access.validate, access.events, incidents.create |
| unit_owner | /imtun/owner | properties.own, billing.own, requests.own, requests.create, announcements.read, residents.delegate, access.create, meters.own, meetings.read, meetings.vote, documents.read, leases.own |
| renter | /imtun/renter | properties.own, billing.own, requests.own, requests.create, announcements.read, access.create, meters.own, documents.read, leases.own |
| family | /imtun/family | properties.own, requests.own, requests.create, announcements.read, documents.read |

Техник и подрядчик видят назначенные им записи. Житель — собственные заявки и обязанности плательщика; семья не получает финансы. Поддержка работает с назначенными обращениями, доступ к клиентским данным требует отдельного одобренного срочного разрешения. Делегированная семья получает только выбранные собственником разрешения. Администратор платформы не получает финансы жителей автоматически.

15 отдельных demo-аккаунтов в двух организациях: локальный файл `.local/demo-accounts.md`; пароли не публикуются и не входят в ZIP.

Продуктовые переходы и карта совместимости: [PRODUCT-PORTALS.md](PRODUCT-PORTALS.md).
